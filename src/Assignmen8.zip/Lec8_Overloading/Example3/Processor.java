
package Lec8_Overloading.Example3;

public class Processor {
    public static void main(String[] args) {
OverloadingExample3.printInfo("Tony",25);
}
}
