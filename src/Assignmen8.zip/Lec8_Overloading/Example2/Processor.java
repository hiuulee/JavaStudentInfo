package Lec8_Overloading.Example2;

public class Processor {

    public static void main(String[] args) {
        System.out.println(OverloadingExample2.multiply(1, 2));
    }
}
