package Lec8_Overloading.Example1;

public class Processor {

    public static void main(String[] args) {
        System.out.println(OverloadingExample.add(1, 2));
        System.out.println(OverloadingExample.add(1, 2, 3));
    }
}
