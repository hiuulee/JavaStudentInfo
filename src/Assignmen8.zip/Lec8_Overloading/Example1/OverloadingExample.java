package Lec8_Overloading.Example1;

public class OverloadingExample {

    public static int add(int a, int b) {
        return a + b;
    }

    public static int add(int a, int b, int c) {
        return a + b + c;
    }
}
