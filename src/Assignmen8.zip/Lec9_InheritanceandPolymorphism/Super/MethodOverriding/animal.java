
package Lec9_InheritanceandPolymorphism.Super.MethodOverriding;

public class animal {
 void makeSound(){
System.out.println("Make a sound");
}   
}
