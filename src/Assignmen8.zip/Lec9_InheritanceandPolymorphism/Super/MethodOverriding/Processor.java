package Lec9_InheritanceandPolymorphism.Super.MethodOverriding;

public class Processor {

    public static void main(String[] args) {
        Cat cat = new Cat();
        cat.makeSound();
    }
}
