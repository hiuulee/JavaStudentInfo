
package Lec9_InheritanceandPolymorphism.Super.MethodOverriding;


public class Cat extends animal {
    @Override
    void makeSound(){
        System.out.println("Meows meows");
    }
    
}
