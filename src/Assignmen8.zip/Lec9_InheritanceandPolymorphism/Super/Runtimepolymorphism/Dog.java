package Lec9_InheritanceandPolymorphism.Super.Runtimepolymorphism;

public class Dog extends Animal {

    @Override
    void makeSound() {
        System.out.println("Barks barks");
    }

}
