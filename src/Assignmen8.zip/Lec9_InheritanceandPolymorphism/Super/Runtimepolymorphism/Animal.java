package Lec9_InheritanceandPolymorphism.Super.Runtimepolymorphism;

public class Animal {

    void makeSound() {
        System.out.println("Make a sound");
        
}
}
