package Lec9_InheritanceandPolymorphism.Super.Runtimepolymorphism;

public class Cat extends Animal {

    @Override
    void makeSound() {
        System.out.println("Meows meows");
    }
}
