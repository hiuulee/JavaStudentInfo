
package Lec9_InheritanceandPolymorphism.Super.constructor;

public class Husky extends Dog {
    Husky(){
super(); 
System.out.println("Husky's constructor is invoked");
}
}
