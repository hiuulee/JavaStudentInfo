
package Lec9_InheritanceandPolymorphism.Super.constructor;


public class Dog {
    Dog(){
System.out.println("Dog's constructor is invoked");
}
}
