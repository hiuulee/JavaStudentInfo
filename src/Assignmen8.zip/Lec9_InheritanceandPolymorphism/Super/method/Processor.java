package Lec9_InheritanceandPolymorphism.Super.method;

public class Processor {

    public static void main(String[] args) {
        Husky husky = new Husky();
        husky.displayInformation();
    }
}
