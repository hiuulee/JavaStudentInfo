
package Lec9_InheritanceandPolymorphism.Super.method;


public class Dog {
    void displayPrice(){
System.out.println("Dog's price is 1000 USD");
}
}
