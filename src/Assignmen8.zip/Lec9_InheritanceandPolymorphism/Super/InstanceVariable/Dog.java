
package Lec9_InheritanceandPolymorphism.Super.InstanceVariable;


public class Dog {
    int price = 1000;
}
