package Lec9_InheritanceandPolymorphism.Super.InstanceVariable;

public class Processor {

    public static void main(String[] args) {
        Husky husky = new Husky();
        husky.displayPrice();
    }
}
