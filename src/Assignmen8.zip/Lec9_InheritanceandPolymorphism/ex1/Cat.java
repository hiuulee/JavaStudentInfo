
package Lec9_InheritanceandPolymorphism.ex1;

public class Cat extends Animal {
  String catID = "cat";
  void catchMouse(){
      System.out.println("Catch the mouse");
  }
}
