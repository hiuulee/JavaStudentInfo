package Lec9_InheritanceandPolymorphism.ex1;

public class Animal {

    String source = "VietNam";

    void makeSound() {
        System.out.println("");
    }
}
