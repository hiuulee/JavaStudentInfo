package Lec10_Abstraction.AbstractClass.NonAbstractMethod;

public abstract class Shape {

    public void displayInfo() {
        System.out.println("This is a shape");
    }
}
