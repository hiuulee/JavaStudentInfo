package Lec10_Abstraction.AbstractClass.NonAbstractMethod;

public class Square extends Shape {

}
