package Lec10_Abstraction.AbstractClass.NonAbstractMethod;

public class Processor {

    public static void main(String[] args) {
        Square square = new Square();
        square.displayInfo();
    }
}
