package Lec10_Abstraction.Interface.Example3;

public class Processor {

    public static void main(String[] args) {
        Circle circle = new Circle();
        circle.drawShape();
        circle.fillColor();
    }
}
