package Lec10_Abstraction.Interface.Example3;

public interface IShape {

    void drawShape();
}
