package Lec10_Abstraction.Interface.Example3;

public interface IColor extends IShape {

    void fillColor();
}
