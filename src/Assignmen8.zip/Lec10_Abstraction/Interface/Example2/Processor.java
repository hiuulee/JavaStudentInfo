
package Lec10_Abstraction.Interface.Example2;


public class Processor {
    public static void main(String[] args) {
Circle circle = new Circle();
circle.drawShape();
circle.fillColor();
}
}
